# WebNovel App (v0.1 skeleton)

Запуск:
1) Windows: запустите `run.bat` (создаст venv, поставит PySide6, запустит приложение).
2) Очистка кешей: `clean_cache.bat`.

Версию приложение берёт из файла `VERSION` (пример: `1.0.3`).

Если PySide6 не ставится на вашей версии Python, используйте Python 3.11–3.12.
